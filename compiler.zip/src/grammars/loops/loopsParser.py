# Generated from src/grammars/loops/loops.g4 by ANTLR 4.9.1
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO
import sys


def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3")
        buf.write(u";\u00f1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t")
        buf.write(u"\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write(u"\3\2\6\2\34\n\2\r\2\16\2\35\3\3\3\3\3\3\3\3\3\3\3\3\3")
        buf.write(u"\3\3\3\3\3\3\3\3\3\3\3\5\3,\n\3\3\4\3\4\3\4\3\4\3\4\3")
        buf.write(u"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4?\n")
        buf.write(u"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3")
        buf.write(u"\4\3\4\3\4\7\4P\n\4\f\4\16\4S\13\4\3\5\3\5\3\5\3\5\3")
        buf.write(u"\5\5\5Z\n\5\3\6\3\6\3\6\3\6\5\6`\n\6\3\7\3\7\3\7\3\7")
        buf.write(u"\5\7f\n\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7o\n\7\f\7\16")
        buf.write(u"\7r\13\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7|\n\7\f\7")
        buf.write(u"\16\7\177\13\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7\u0089")
        buf.write(u"\n\7\f\7\16\7\u008c\13\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7")
        buf.write(u"\7\7\u0095\n\7\f\7\16\7\u0098\13\7\3\7\3\7\7\7\u009c")
        buf.write(u"\n\7\f\7\16\7\u009f\13\7\3\7\3\7\7\7\u00a3\n\7\f\7\16")
        buf.write(u"\7\u00a6\13\7\5\7\u00a8\n\7\3\7\3\7\3\7\3\7\3\7\3\7\3")
        buf.write(u"\7\3\7\7\7\u00b2\n\7\f\7\16\7\u00b5\13\7\3\7\3\7\3\7")
        buf.write(u"\5\7\u00ba\n\7\3\7\3\7\3\7\7\7\u00bf\n\7\f\7\16\7\u00c2")
        buf.write(u"\13\7\3\7\3\7\5\7\u00c6\n\7\3\b\5\b\u00c9\n\b\3\b\5\b")
        buf.write(u"\u00cc\n\b\3\b\3\b\5\b\u00d0\n\b\3\b\5\b\u00d3\n\b\3")
        buf.write(u"\b\3\b\5\b\u00d7\n\b\5\b\u00d9\n\b\3\t\3\t\3\t\3\t\5")
        buf.write(u"\t\u00df\n\t\3\n\3\n\3\n\3\13\3\13\3\13\3\13\3\f\3\f")
        buf.write(u"\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\r\2\3\6\16\2\4\6\b\n\f")
        buf.write(u"\16\20\22\24\26\30\2\f\4\2\3\3\33\33\3\2\22\23\3\2\5")
        buf.write(u"\6\4\2\3\4\13\13\4\2\7\b\f\r\4\2\t\t\16\16\3\2\17\20")
        buf.write(u"\3\2\37 \4\2!$**\3\2&(\2\u010e\2\33\3\2\2\2\4+\3\2\2")
        buf.write(u"\2\6>\3\2\2\2\bY\3\2\2\2\n_\3\2\2\2\f\u00c5\3\2\2\2\16")
        buf.write(u"\u00d8\3\2\2\2\20\u00de\3\2\2\2\22\u00e0\3\2\2\2\24\u00e3")
        buf.write(u"\3\2\2\2\26\u00e7\3\2\2\2\30\u00eb\3\2\2\2\32\34\5\4")
        buf.write(u"\3\2\33\32\3\2\2\2\34\35\3\2\2\2\35\33\3\2\2\2\35\36")
        buf.write(u"\3\2\2\2\36\3\3\2\2\2\37 \5\24\13\2 !\7\30\2\2!,\3\2")
        buf.write(u"\2\2\"#\5\22\n\2#$\7\30\2\2$,\3\2\2\2%&\5\26\f\2&\'\7")
        buf.write(u"\30\2\2\',\3\2\2\2()\5\6\4\2)*\7\30\2\2*,\3\2\2\2+\37")
        buf.write(u"\3\2\2\2+\"\3\2\2\2+%\3\2\2\2+(\3\2\2\2,\5\3\2\2\2-.")
        buf.write(u"\b\4\1\2./\7\24\2\2/\60\5\6\4\2\60\61\7\25\2\2\61?\3")
        buf.write(u"\2\2\2\62\63\t\2\2\2\63?\78\2\2\64\65\t\3\2\2\65?\78")
        buf.write(u"\2\2\66\67\78\2\2\67?\t\3\2\289\t\4\2\29?\5\6\4\13:;")
        buf.write(u"\7\21\2\2;?\5\6\4\n<?\5\20\t\2=?\78\2\2>-\3\2\2\2>\62")
        buf.write(u"\3\2\2\2>\64\3\2\2\2>\66\3\2\2\2>8\3\2\2\2>:\3\2\2\2")
        buf.write(u"><\3\2\2\2>=\3\2\2\2?Q\3\2\2\2@A\f\t\2\2AB\t\5\2\2BP")
        buf.write(u"\5\6\4\nCD\f\b\2\2DE\t\4\2\2EP\5\6\4\tFG\f\7\2\2GH\t")
        buf.write(u"\6\2\2HP\5\6\4\bIJ\f\6\2\2JK\t\7\2\2KP\5\6\4\7LM\f\5")
        buf.write(u"\2\2MN\t\b\2\2NP\5\6\4\6O@\3\2\2\2OC\3\2\2\2OF\3\2\2")
        buf.write(u"\2OI\3\2\2\2OL\3\2\2\2PS\3\2\2\2QO\3\2\2\2QR\3\2\2\2")
        buf.write(u"R\7\3\2\2\2SQ\3\2\2\2TZ\5\4\3\2UV\7\63\2\2VZ\7\30\2\2")
        buf.write(u"WX\7\64\2\2XZ\7\30\2\2YT\3\2\2\2YU\3\2\2\2YW\3\2\2\2")
        buf.write(u"Z\t\3\2\2\2[\\\t\3\2\2\\`\78\2\2]^\78\2\2^`\t\3\2\2_")
        buf.write(u"[\3\2\2\2_]\3\2\2\2`\13\3\2\2\2ab\7\61\2\2be\7\24\2\2")
        buf.write(u"cf\5\24\13\2df\5\26\f\2ec\3\2\2\2ed\3\2\2\2fg\3\2\2\2")
        buf.write(u"gh\7\30\2\2hi\5\6\4\2ij\7\30\2\2jk\5\n\6\2kl\7\25\2\2")
        buf.write(u"lp\7\26\2\2mo\5\b\5\2nm\3\2\2\2or\3\2\2\2pn\3\2\2\2p")
        buf.write(u"q\3\2\2\2qs\3\2\2\2rp\3\2\2\2st\7\27\2\2t\u00c6\3\2\2")
        buf.write(u"\2uv\7\62\2\2vw\7\24\2\2wx\5\6\4\2xy\7\25\2\2y}\7\26")
        buf.write(u"\2\2z|\5\b\5\2{z\3\2\2\2|\177\3\2\2\2}{\3\2\2\2}~\3\2")
        buf.write(u"\2\2~\u0080\3\2\2\2\177}\3\2\2\2\u0080\u0081\7\27\2\2")
        buf.write(u"\u0081\u00c6\3\2\2\2\u0082\u0083\7.\2\2\u0083\u0084\7")
        buf.write(u"\24\2\2\u0084\u0085\5\6\4\2\u0085\u0086\7\25\2\2\u0086")
        buf.write(u"\u008a\7\26\2\2\u0087\u0089\5\b\5\2\u0088\u0087\3\2\2")
        buf.write(u"\2\u0089\u008c\3\2\2\2\u008a\u0088\3\2\2\2\u008a\u008b")
        buf.write(u"\3\2\2\2\u008b\u008d\3\2\2\2\u008c\u008a\3\2\2\2\u008d")
        buf.write(u"\u009d\7\27\2\2\u008e\u008f\7/\2\2\u008f\u0090\7\24\2")
        buf.write(u"\2\u0090\u0091\5\6\4\2\u0091\u0092\7\25\2\2\u0092\u0096")
        buf.write(u"\7\26\2\2\u0093\u0095\5\b\5\2\u0094\u0093\3\2\2\2\u0095")
        buf.write(u"\u0098\3\2\2\2\u0096\u0094\3\2\2\2\u0096\u0097\3\2\2")
        buf.write(u"\2\u0097\u0099\3\2\2\2\u0098\u0096\3\2\2\2\u0099\u009a")
        buf.write(u"\7\27\2\2\u009a\u009c\3\2\2\2\u009b\u008e\3\2\2\2\u009c")
        buf.write(u"\u009f\3\2\2\2\u009d\u009b\3\2\2\2\u009d\u009e\3\2\2")
        buf.write(u"\2\u009e\u00a7\3\2\2\2\u009f\u009d\3\2\2\2\u00a0\u00a4")
        buf.write(u"\7\60\2\2\u00a1\u00a3\5\b\5\2\u00a2\u00a1\3\2\2\2\u00a3")
        buf.write(u"\u00a6\3\2\2\2\u00a4\u00a2\3\2\2\2\u00a4\u00a5\3\2\2")
        buf.write(u"\2\u00a5\u00a8\3\2\2\2\u00a6\u00a4\3\2\2\2\u00a7\u00a0")
        buf.write(u"\3\2\2\2\u00a7\u00a8\3\2\2\2\u00a8\u00c6\3\2\2\2\u00a9")
        buf.write(u"\u00aa\7\65\2\2\u00aa\u00ab\7\24\2\2\u00ab\u00ac\5\6")
        buf.write(u"\4\2\u00ac\u00ad\7\25\2\2\u00ad\u00b3\7\26\2\2\u00ae")
        buf.write(u"\u00af\7\66\2\2\u00af\u00b0\7\31\2\2\u00b0\u00b2\5\4")
        buf.write(u"\3\2\u00b1\u00ae\3\2\2\2\u00b2\u00b5\3\2\2\2\u00b3\u00b1")
        buf.write(u"\3\2\2\2\u00b3\u00b4\3\2\2\2\u00b4\u00b9\3\2\2\2\u00b5")
        buf.write(u"\u00b3\3\2\2\2\u00b6\u00b7\7\67\2\2\u00b7\u00b8\7\31")
        buf.write(u"\2\2\u00b8\u00ba\5\4\3\2\u00b9\u00b6\3\2\2\2\u00b9\u00ba")
        buf.write(u"\3\2\2\2\u00ba\u00c0\3\2\2\2\u00bb\u00bc\7\66\2\2\u00bc")
        buf.write(u"\u00bd\7\31\2\2\u00bd\u00bf\5\4\3\2\u00be\u00bb\3\2\2")
        buf.write(u"\2\u00bf\u00c2\3\2\2\2\u00c0\u00be\3\2\2\2\u00c0\u00c1")
        buf.write(u"\3\2\2\2\u00c1\u00c3\3\2\2\2\u00c2\u00c0\3\2\2\2\u00c3")
        buf.write(u"\u00c4\7\27\2\2\u00c4\u00c6\3\2\2\2\u00c5a\3\2\2\2\u00c5")
        buf.write(u"u\3\2\2\2\u00c5\u0082\3\2\2\2\u00c5\u00a9\3\2\2\2\u00c6")
        buf.write(u"\r\3\2\2\2\u00c7\u00c9\7\36\2\2\u00c8\u00c7\3\2\2\2\u00c8")
        buf.write(u"\u00c9\3\2\2\2\u00c9\u00cb\3\2\2\2\u00ca\u00cc\t\t\2")
        buf.write(u"\2\u00cb\u00ca\3\2\2\2\u00cb\u00cc\3\2\2\2\u00cc\u00cd")
        buf.write(u"\3\2\2\2\u00cd\u00cf\t\n\2\2\u00ce\u00d0\7\3\2\2\u00cf")
        buf.write(u"\u00ce\3\2\2\2\u00cf\u00d0\3\2\2\2\u00d0\u00d9\3\2\2")
        buf.write(u"\2\u00d1\u00d3\7\36\2\2\u00d2\u00d1\3\2\2\2\u00d2\u00d3")
        buf.write(u"\3\2\2\2\u00d3\u00d4\3\2\2\2\u00d4\u00d6\t\13\2\2\u00d5")
        buf.write(u"\u00d7\7\3\2\2\u00d6\u00d5\3\2\2\2\u00d6\u00d7\3\2\2")
        buf.write(u"\2\u00d7\u00d9\3\2\2\2\u00d8\u00c8\3\2\2\2\u00d8\u00d2")
        buf.write(u"\3\2\2\2\u00d9\17\3\2\2\2\u00da\u00df\7)\2\2\u00db\u00df")
        buf.write(u"\7%\2\2\u00dc\u00df\7,\2\2\u00dd\u00df\7+\2\2\u00de\u00da")
        buf.write(u"\3\2\2\2\u00de\u00db\3\2\2\2\u00de\u00dc\3\2\2\2\u00de")
        buf.write(u"\u00dd\3\2\2\2\u00df\21\3\2\2\2\u00e0\u00e1\5\16\b\2")
        buf.write(u"\u00e1\u00e2\78\2\2\u00e2\23\3\2\2\2\u00e3\u00e4\5\22")
        buf.write(u"\n\2\u00e4\u00e5\7\n\2\2\u00e5\u00e6\5\6\4\2\u00e6\25")
        buf.write(u"\3\2\2\2\u00e7\u00e8\78\2\2\u00e8\u00e9\7\n\2\2\u00e9")
        buf.write(u"\u00ea\5\6\4\2\u00ea\27\3\2\2\2\u00eb\u00ec\7-\2\2\u00ec")
        buf.write(u"\u00ed\7\24\2\2\u00ed\u00ee\5\6\4\2\u00ee\u00ef\7\25")
        buf.write(u"\2\2\u00ef\31\3\2\2\2\34\35+>OQY_ep}\u008a\u0096\u009d")
        buf.write(u"\u00a4\u00a7\u00b3\u00b9\u00c0\u00c5\u00c8\u00cb\u00cf")
        buf.write(u"\u00d2\u00d6\u00d8\u00de")
        return buf.getvalue()


class loopsParser ( Parser ):

    grammarFileName = "loops.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ u"<INVALID>", u"'*'", u"'/'", u"'+'", u"'-'", u"'<'", 
                     u"'>'", u"'=='", u"'='", u"'%'", u"'<='", u"'>='", 
                     u"'!='", u"'&&'", u"'||'", u"'!'", u"'++'", u"'--'", 
                     u"'('", u"')'", u"'{'", u"'}'", u"';'", u"':'", u"'.'", 
                     u"'&'", u"'''", u"'\\'", u"'const'", u"'signed'", u"'unsigned'", 
                     u"'int'", u"<INVALID>", u"<INVALID>", u"<INVALID>", 
                     u"<INVALID>", u"'float'", u"'double'", u"'long double'", 
                     u"<INVALID>", u"'char'", u"<INVALID>", u"<INVALID>", 
                     u"'printf'", u"'if'", u"'else if'", u"'else'", u"'for'", 
                     u"'while'", u"'break'", u"'continue'", u"'switch'", 
                     u"'case'", u"'default'" ]

    symbolicNames = [ u"<INVALID>", u"MUL", u"DIV", u"ADD", u"SUB", u"LT", 
                      u"GT", u"DEQ", u"EQ", u"MOD", u"LTE", u"GTE", u"NEQ", 
                      u"AND", u"OR", u"NOT", u"INCR", u"DECR", u"LBRACKET", 
                      u"RBRACKET", u"LCURLY", u"RCURLY", u"END_INSTR", u"D_POINT", 
                      u"DOT", u"REF", u"SQUOTE", u"ESC", u"CONST", u"SIGNED", 
                      u"UNSIGNED", u"INT_PREF", u"SHORT_PREF", u"LONG_PREF", 
                      u"LONG_LONG_PREF", u"INT", u"FLOAT_PREF", u"DOUBLE_PREF", 
                      u"LONG_DOUBLE_PREF", u"FLOAT", u"CHAR_PREF", u"CHAR", 
                      u"STRING", u"PRINTF", u"IF", u"ELIF", u"ELSE", u"FOR", 
                      u"WHILE", u"BREAK", u"CONTINUE", u"SWITCH", u"CASE", 
                      u"DEFAULT", u"ID", u"WS", u"SINGLE_COMMENT", u"MULTI_COMMENT" ]

    RULE_prog = 0
    RULE_stat = 1
    RULE_expr = 2
    RULE_loop_stat = 3
    RULE_increment = 4
    RULE_block_stat = 5
    RULE_type_specifier = 6
    RULE_literal = 7
    RULE_declaration = 8
    RULE_definition = 9
    RULE_assignment = 10
    RULE_function_call = 11

    ruleNames =  [ u"prog", u"stat", u"expr", u"loop_stat", u"increment", 
                   u"block_stat", u"type_specifier", u"literal", u"declaration", 
                   u"definition", u"assignment", u"function_call" ]

    EOF = Token.EOF
    MUL=1
    DIV=2
    ADD=3
    SUB=4
    LT=5
    GT=6
    DEQ=7
    EQ=8
    MOD=9
    LTE=10
    GTE=11
    NEQ=12
    AND=13
    OR=14
    NOT=15
    INCR=16
    DECR=17
    LBRACKET=18
    RBRACKET=19
    LCURLY=20
    RCURLY=21
    END_INSTR=22
    D_POINT=23
    DOT=24
    REF=25
    SQUOTE=26
    ESC=27
    CONST=28
    SIGNED=29
    UNSIGNED=30
    INT_PREF=31
    SHORT_PREF=32
    LONG_PREF=33
    LONG_LONG_PREF=34
    INT=35
    FLOAT_PREF=36
    DOUBLE_PREF=37
    LONG_DOUBLE_PREF=38
    FLOAT=39
    CHAR_PREF=40
    CHAR=41
    STRING=42
    PRINTF=43
    IF=44
    ELIF=45
    ELSE=46
    FOR=47
    WHILE=48
    BREAK=49
    CONTINUE=50
    SWITCH=51
    CASE=52
    DEFAULT=53
    ID=54
    WS=55
    SINGLE_COMMENT=56
    MULTI_COMMENT=57

    def __init__(self, input, output=sys.stdout):
        super(loopsParser, self).__init__(input, output=output)
        self.checkVersion("4.9.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.ProgContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return loopsParser.RULE_prog

     
        def copyFrom(self, ctx):
            super(loopsParser.ProgContext, self).copyFrom(ctx)



    class ProgramContext(ProgContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ProgContext)
            super(loopsParser.ProgramContext, self).__init__(parser)
            self.copyFrom(ctx)

        def stat(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.StatContext)
            else:
                return self.getTypedRuleContext(loopsParser.StatContext,i)


        def enterRule(self, listener):
            if hasattr(listener, "enterProgram"):
                listener.enterProgram(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitProgram"):
                listener.exitProgram(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitProgram"):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)



    def prog(self):

        localctx = loopsParser.ProgContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_prog)
        self._la = 0 # Token type
        try:
            localctx = loopsParser.ProgramContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 25 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 24
                self.stat()
                self.state = 27 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.ID))) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StatContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.StatContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return loopsParser.RULE_stat

     
        def copyFrom(self, ctx):
            super(loopsParser.StatContext, self).copyFrom(ctx)



    class DefinitionStatementContext(StatContext):

        def __init__(self, parser, ctx): # actually a loopsParser.StatContext)
            super(loopsParser.DefinitionStatementContext, self).__init__(parser)
            self.copyFrom(ctx)

        def definition(self):
            return self.getTypedRuleContext(loopsParser.DefinitionContext,0)

        def END_INSTR(self):
            return self.getToken(loopsParser.END_INSTR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterDefinitionStatement"):
                listener.enterDefinitionStatement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDefinitionStatement"):
                listener.exitDefinitionStatement(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitDefinitionStatement"):
                return visitor.visitDefinitionStatement(self)
            else:
                return visitor.visitChildren(self)


    class AssignmentStatementContext(StatContext):

        def __init__(self, parser, ctx): # actually a loopsParser.StatContext)
            super(loopsParser.AssignmentStatementContext, self).__init__(parser)
            self.copyFrom(ctx)

        def assignment(self):
            return self.getTypedRuleContext(loopsParser.AssignmentContext,0)

        def END_INSTR(self):
            return self.getToken(loopsParser.END_INSTR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterAssignmentStatement"):
                listener.enterAssignmentStatement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitAssignmentStatement"):
                listener.exitAssignmentStatement(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitAssignmentStatement"):
                return visitor.visitAssignmentStatement(self)
            else:
                return visitor.visitChildren(self)


    class ExpressionStatementContext(StatContext):

        def __init__(self, parser, ctx): # actually a loopsParser.StatContext)
            super(loopsParser.ExpressionStatementContext, self).__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)

        def END_INSTR(self):
            return self.getToken(loopsParser.END_INSTR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterExpressionStatement"):
                listener.enterExpressionStatement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitExpressionStatement"):
                listener.exitExpressionStatement(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitExpressionStatement"):
                return visitor.visitExpressionStatement(self)
            else:
                return visitor.visitChildren(self)


    class DeclarationStatementContext(StatContext):

        def __init__(self, parser, ctx): # actually a loopsParser.StatContext)
            super(loopsParser.DeclarationStatementContext, self).__init__(parser)
            self.copyFrom(ctx)

        def declaration(self):
            return self.getTypedRuleContext(loopsParser.DeclarationContext,0)

        def END_INSTR(self):
            return self.getToken(loopsParser.END_INSTR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterDeclarationStatement"):
                listener.enterDeclarationStatement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDeclarationStatement"):
                listener.exitDeclarationStatement(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitDeclarationStatement"):
                return visitor.visitDeclarationStatement(self)
            else:
                return visitor.visitChildren(self)



    def stat(self):

        localctx = loopsParser.StatContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_stat)
        try:
            self.state = 41
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                localctx = loopsParser.DefinitionStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 29
                self.definition()
                self.state = 30
                self.match(loopsParser.END_INSTR)
                pass

            elif la_ == 2:
                localctx = loopsParser.DeclarationStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 32
                self.declaration()
                self.state = 33
                self.match(loopsParser.END_INSTR)
                pass

            elif la_ == 3:
                localctx = loopsParser.AssignmentStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 35
                self.assignment()
                self.state = 36
                self.match(loopsParser.END_INSTR)
                pass

            elif la_ == 4:
                localctx = loopsParser.ExpressionStatementContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 38
                self.expr(0)
                self.state = 39
                self.match(loopsParser.END_INSTR)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.ExprContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return loopsParser.RULE_expr

     
        def copyFrom(self, ctx):
            super(loopsParser.ExprContext, self).copyFrom(ctx)


    class UnaryOpContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.UnaryOpContext, self).__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)

        def ADD(self):
            return self.getToken(loopsParser.ADD, 0)
        def SUB(self):
            return self.getToken(loopsParser.SUB, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterUnaryOp"):
                listener.enterUnaryOp(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitUnaryOp"):
                listener.exitUnaryOp(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitUnaryOp"):
                return visitor.visitUnaryOp(self)
            else:
                return visitor.visitChildren(self)


    class IdentifierContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.IdentifierContext, self).__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(loopsParser.ID, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterIdentifier"):
                listener.enterIdentifier(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIdentifier"):
                listener.exitIdentifier(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitIdentifier"):
                return visitor.visitIdentifier(self)
            else:
                return visitor.visitChildren(self)


    class BracketsContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.BracketsContext, self).__init__(parser)
            self.copyFrom(ctx)

        def LBRACKET(self):
            return self.getToken(loopsParser.LBRACKET, 0)
        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)

        def RBRACKET(self):
            return self.getToken(loopsParser.RBRACKET, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterBrackets"):
                listener.enterBrackets(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBrackets"):
                listener.exitBrackets(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBrackets"):
                return visitor.visitBrackets(self)
            else:
                return visitor.visitChildren(self)


    class UnaryOpIdentifierSuffixContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.UnaryOpIdentifierSuffixContext, self).__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(loopsParser.ID, 0)
        def INCR(self):
            return self.getToken(loopsParser.INCR, 0)
        def DECR(self):
            return self.getToken(loopsParser.DECR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterUnaryOpIdentifierSuffix"):
                listener.enterUnaryOpIdentifierSuffix(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitUnaryOpIdentifierSuffix"):
                listener.exitUnaryOpIdentifierSuffix(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitUnaryOpIdentifierSuffix"):
                return visitor.visitUnaryOpIdentifierSuffix(self)
            else:
                return visitor.visitChildren(self)


    class UnaryOpPointerContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.UnaryOpPointerContext, self).__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(loopsParser.ID, 0)
        def MUL(self):
            return self.getToken(loopsParser.MUL, 0)
        def REF(self):
            return self.getToken(loopsParser.REF, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterUnaryOpPointer"):
                listener.enterUnaryOpPointer(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitUnaryOpPointer"):
                listener.exitUnaryOpPointer(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitUnaryOpPointer"):
                return visitor.visitUnaryOpPointer(self)
            else:
                return visitor.visitChildren(self)


    class LiteralExprContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.LiteralExprContext, self).__init__(parser)
            self.copyFrom(ctx)

        def literal(self):
            return self.getTypedRuleContext(loopsParser.LiteralContext,0)


        def enterRule(self, listener):
            if hasattr(listener, "enterLiteralExpr"):
                listener.enterLiteralExpr(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitLiteralExpr"):
                listener.exitLiteralExpr(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitLiteralExpr"):
                return visitor.visitLiteralExpr(self)
            else:
                return visitor.visitChildren(self)


    class UnaryOpBooleanContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.UnaryOpBooleanContext, self).__init__(parser)
            self.copyFrom(ctx)

        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)

        def NOT(self):
            return self.getToken(loopsParser.NOT, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterUnaryOpBoolean"):
                listener.enterUnaryOpBoolean(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitUnaryOpBoolean"):
                listener.exitUnaryOpBoolean(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitUnaryOpBoolean"):
                return visitor.visitUnaryOpBoolean(self)
            else:
                return visitor.visitChildren(self)


    class UnaryOpIdentifierPrefixContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.UnaryOpIdentifierPrefixContext, self).__init__(parser)
            self.copyFrom(ctx)

        def ID(self):
            return self.getToken(loopsParser.ID, 0)
        def INCR(self):
            return self.getToken(loopsParser.INCR, 0)
        def DECR(self):
            return self.getToken(loopsParser.DECR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterUnaryOpIdentifierPrefix"):
                listener.enterUnaryOpIdentifierPrefix(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitUnaryOpIdentifierPrefix"):
                listener.exitUnaryOpIdentifierPrefix(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitUnaryOpIdentifierPrefix"):
                return visitor.visitUnaryOpIdentifierPrefix(self)
            else:
                return visitor.visitChildren(self)


    class BinaryOpContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.BinaryOpContext, self).__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.ExprContext)
            else:
                return self.getTypedRuleContext(loopsParser.ExprContext,i)

        def MUL(self):
            return self.getToken(loopsParser.MUL, 0)
        def DIV(self):
            return self.getToken(loopsParser.DIV, 0)
        def MOD(self):
            return self.getToken(loopsParser.MOD, 0)
        def ADD(self):
            return self.getToken(loopsParser.ADD, 0)
        def SUB(self):
            return self.getToken(loopsParser.SUB, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterBinaryOp"):
                listener.enterBinaryOp(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBinaryOp"):
                listener.exitBinaryOp(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBinaryOp"):
                return visitor.visitBinaryOp(self)
            else:
                return visitor.visitChildren(self)


    class BinaryOpBooleanContext(ExprContext):

        def __init__(self, parser, ctx): # actually a loopsParser.ExprContext)
            super(loopsParser.BinaryOpBooleanContext, self).__init__(parser)
            self.copyFrom(ctx)

        def expr(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.ExprContext)
            else:
                return self.getTypedRuleContext(loopsParser.ExprContext,i)

        def LT(self):
            return self.getToken(loopsParser.LT, 0)
        def GT(self):
            return self.getToken(loopsParser.GT, 0)
        def LTE(self):
            return self.getToken(loopsParser.LTE, 0)
        def GTE(self):
            return self.getToken(loopsParser.GTE, 0)
        def DEQ(self):
            return self.getToken(loopsParser.DEQ, 0)
        def NEQ(self):
            return self.getToken(loopsParser.NEQ, 0)
        def AND(self):
            return self.getToken(loopsParser.AND, 0)
        def OR(self):
            return self.getToken(loopsParser.OR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterBinaryOpBoolean"):
                listener.enterBinaryOpBoolean(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBinaryOpBoolean"):
                listener.exitBinaryOpBoolean(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBinaryOpBoolean"):
                return visitor.visitBinaryOpBoolean(self)
            else:
                return visitor.visitChildren(self)



    def expr(self, _p=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = loopsParser.ExprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 4
        self.enterRecursionRule(localctx, 4, self.RULE_expr, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 60
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                localctx = loopsParser.BracketsContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 44
                self.match(loopsParser.LBRACKET)
                self.state = 45
                self.expr(0)
                self.state = 46
                self.match(loopsParser.RBRACKET)
                pass

            elif la_ == 2:
                localctx = loopsParser.UnaryOpPointerContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 48
                _la = self._input.LA(1)
                if not(_la==loopsParser.MUL or _la==loopsParser.REF):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 49
                self.match(loopsParser.ID)
                pass

            elif la_ == 3:
                localctx = loopsParser.UnaryOpIdentifierPrefixContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 50
                _la = self._input.LA(1)
                if not(_la==loopsParser.INCR or _la==loopsParser.DECR):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 51
                self.match(loopsParser.ID)
                pass

            elif la_ == 4:
                localctx = loopsParser.UnaryOpIdentifierSuffixContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 52
                self.match(loopsParser.ID)
                self.state = 53
                _la = self._input.LA(1)
                if not(_la==loopsParser.INCR or _la==loopsParser.DECR):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 5:
                localctx = loopsParser.UnaryOpContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 54
                _la = self._input.LA(1)
                if not(_la==loopsParser.ADD or _la==loopsParser.SUB):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 55
                self.expr(9)
                pass

            elif la_ == 6:
                localctx = loopsParser.UnaryOpBooleanContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx

                self.state = 56
                self.match(loopsParser.NOT)
                self.state = 57
                self.expr(8)
                pass

            elif la_ == 7:
                localctx = loopsParser.LiteralExprContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 58
                self.literal()
                pass

            elif la_ == 8:
                localctx = loopsParser.IdentifierContext(self, localctx)
                self._ctx = localctx
                _prevctx = localctx
                self.state = 59
                self.match(loopsParser.ID)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 79
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 77
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
                    if la_ == 1:
                        localctx = loopsParser.BinaryOpContext(self, loopsParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 62
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 63
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.DIV) | (1 << loopsParser.MOD))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 64
                        self.expr(8)
                        pass

                    elif la_ == 2:
                        localctx = loopsParser.BinaryOpContext(self, loopsParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 65
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 66
                        _la = self._input.LA(1)
                        if not(_la==loopsParser.ADD or _la==loopsParser.SUB):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 67
                        self.expr(7)
                        pass

                    elif la_ == 3:
                        localctx = loopsParser.BinaryOpBooleanContext(self, loopsParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 68
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 69
                        _la = self._input.LA(1)
                        if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.LT) | (1 << loopsParser.GT) | (1 << loopsParser.LTE) | (1 << loopsParser.GTE))) != 0)):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 70
                        self.expr(6)
                        pass

                    elif la_ == 4:
                        localctx = loopsParser.BinaryOpBooleanContext(self, loopsParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 71
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 72
                        _la = self._input.LA(1)
                        if not(_la==loopsParser.DEQ or _la==loopsParser.NEQ):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 73
                        self.expr(5)
                        pass

                    elif la_ == 5:
                        localctx = loopsParser.BinaryOpBooleanContext(self, loopsParser.ExprContext(self, _parentctx, _parentState))
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_expr)
                        self.state = 74
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 75
                        _la = self._input.LA(1)
                        if not(_la==loopsParser.AND or _la==loopsParser.OR):
                            self._errHandler.recoverInline(self)
                        else:
                            self._errHandler.reportMatch(self)
                            self.consume()
                        self.state = 76
                        self.expr(4)
                        pass

             
                self.state = 81
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Loop_statContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.Loop_statContext, self).__init__(parent, invokingState)
            self.parser = parser

        def stat(self):
            return self.getTypedRuleContext(loopsParser.StatContext,0)


        def BREAK(self):
            return self.getToken(loopsParser.BREAK, 0)

        def END_INSTR(self):
            return self.getToken(loopsParser.END_INSTR, 0)

        def CONTINUE(self):
            return self.getToken(loopsParser.CONTINUE, 0)

        def getRuleIndex(self):
            return loopsParser.RULE_loop_stat

        def enterRule(self, listener):
            if hasattr(listener, "enterLoop_stat"):
                listener.enterLoop_stat(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitLoop_stat"):
                listener.exitLoop_stat(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitLoop_stat"):
                return visitor.visitLoop_stat(self)
            else:
                return visitor.visitChildren(self)




    def loop_stat(self):

        localctx = loopsParser.Loop_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_loop_stat)
        try:
            self.state = 87
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [loopsParser.MUL, loopsParser.ADD, loopsParser.SUB, loopsParser.NOT, loopsParser.INCR, loopsParser.DECR, loopsParser.LBRACKET, loopsParser.REF, loopsParser.CONST, loopsParser.SIGNED, loopsParser.UNSIGNED, loopsParser.INT_PREF, loopsParser.SHORT_PREF, loopsParser.LONG_PREF, loopsParser.LONG_LONG_PREF, loopsParser.INT, loopsParser.FLOAT_PREF, loopsParser.DOUBLE_PREF, loopsParser.LONG_DOUBLE_PREF, loopsParser.FLOAT, loopsParser.CHAR_PREF, loopsParser.CHAR, loopsParser.STRING, loopsParser.ID]:
                self.enterOuterAlt(localctx, 1)
                self.state = 82
                self.stat()
                pass
            elif token in [loopsParser.BREAK]:
                self.enterOuterAlt(localctx, 2)
                self.state = 83
                self.match(loopsParser.BREAK)
                self.state = 84
                self.match(loopsParser.END_INSTR)
                pass
            elif token in [loopsParser.CONTINUE]:
                self.enterOuterAlt(localctx, 3)
                self.state = 85
                self.match(loopsParser.CONTINUE)
                self.state = 86
                self.match(loopsParser.END_INSTR)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IncrementContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.IncrementContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(loopsParser.ID, 0)

        def INCR(self):
            return self.getToken(loopsParser.INCR, 0)

        def DECR(self):
            return self.getToken(loopsParser.DECR, 0)

        def getRuleIndex(self):
            return loopsParser.RULE_increment

        def enterRule(self, listener):
            if hasattr(listener, "enterIncrement"):
                listener.enterIncrement(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitIncrement"):
                listener.exitIncrement(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitIncrement"):
                return visitor.visitIncrement(self)
            else:
                return visitor.visitChildren(self)




    def increment(self):

        localctx = loopsParser.IncrementContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_increment)
        self._la = 0 # Token type
        try:
            self.state = 93
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [loopsParser.INCR, loopsParser.DECR]:
                self.enterOuterAlt(localctx, 1)
                self.state = 89
                _la = self._input.LA(1)
                if not(_la==loopsParser.INCR or _la==loopsParser.DECR):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 90
                self.match(loopsParser.ID)
                pass
            elif token in [loopsParser.ID]:
                self.enterOuterAlt(localctx, 2)
                self.state = 91
                self.match(loopsParser.ID)
                self.state = 92
                _la = self._input.LA(1)
                if not(_la==loopsParser.INCR or _la==loopsParser.DECR):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Block_statContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.Block_statContext, self).__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(loopsParser.FOR, 0)

        def LBRACKET(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.LBRACKET)
            else:
                return self.getToken(loopsParser.LBRACKET, i)

        def END_INSTR(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.END_INSTR)
            else:
                return self.getToken(loopsParser.END_INSTR, i)

        def expr(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.ExprContext)
            else:
                return self.getTypedRuleContext(loopsParser.ExprContext,i)


        def increment(self):
            return self.getTypedRuleContext(loopsParser.IncrementContext,0)


        def RBRACKET(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.RBRACKET)
            else:
                return self.getToken(loopsParser.RBRACKET, i)

        def LCURLY(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.LCURLY)
            else:
                return self.getToken(loopsParser.LCURLY, i)

        def RCURLY(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.RCURLY)
            else:
                return self.getToken(loopsParser.RCURLY, i)

        def definition(self):
            return self.getTypedRuleContext(loopsParser.DefinitionContext,0)


        def assignment(self):
            return self.getTypedRuleContext(loopsParser.AssignmentContext,0)


        def loop_stat(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.Loop_statContext)
            else:
                return self.getTypedRuleContext(loopsParser.Loop_statContext,i)


        def WHILE(self):
            return self.getToken(loopsParser.WHILE, 0)

        def IF(self):
            return self.getToken(loopsParser.IF, 0)

        def ELIF(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.ELIF)
            else:
                return self.getToken(loopsParser.ELIF, i)

        def ELSE(self):
            return self.getToken(loopsParser.ELSE, 0)

        def SWITCH(self):
            return self.getToken(loopsParser.SWITCH, 0)

        def CASE(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.CASE)
            else:
                return self.getToken(loopsParser.CASE, i)

        def D_POINT(self, i=None):
            if i is None:
                return self.getTokens(loopsParser.D_POINT)
            else:
                return self.getToken(loopsParser.D_POINT, i)

        def stat(self, i=None):
            if i is None:
                return self.getTypedRuleContexts(loopsParser.StatContext)
            else:
                return self.getTypedRuleContext(loopsParser.StatContext,i)


        def DEFAULT(self):
            return self.getToken(loopsParser.DEFAULT, 0)

        def getRuleIndex(self):
            return loopsParser.RULE_block_stat

        def enterRule(self, listener):
            if hasattr(listener, "enterBlock_stat"):
                listener.enterBlock_stat(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitBlock_stat"):
                listener.exitBlock_stat(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitBlock_stat"):
                return visitor.visitBlock_stat(self)
            else:
                return visitor.visitChildren(self)




    def block_stat(self):

        localctx = loopsParser.Block_statContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_block_stat)
        self._la = 0 # Token type
        try:
            self.state = 195
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [loopsParser.FOR]:
                self.enterOuterAlt(localctx, 1)
                self.state = 95
                self.match(loopsParser.FOR)
                self.state = 96
                self.match(loopsParser.LBRACKET)
                self.state = 99
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [loopsParser.CONST, loopsParser.SIGNED, loopsParser.UNSIGNED, loopsParser.INT_PREF, loopsParser.SHORT_PREF, loopsParser.LONG_PREF, loopsParser.LONG_LONG_PREF, loopsParser.FLOAT_PREF, loopsParser.DOUBLE_PREF, loopsParser.LONG_DOUBLE_PREF, loopsParser.CHAR_PREF]:
                    self.state = 97
                    self.definition()
                    pass
                elif token in [loopsParser.ID]:
                    self.state = 98
                    self.assignment()
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 101
                self.match(loopsParser.END_INSTR)
                self.state = 102
                self.expr(0)
                self.state = 103
                self.match(loopsParser.END_INSTR)
                self.state = 104
                self.increment()
                self.state = 105
                self.match(loopsParser.RBRACKET)
                self.state = 106
                self.match(loopsParser.LCURLY)
                self.state = 110
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.BREAK) | (1 << loopsParser.CONTINUE) | (1 << loopsParser.ID))) != 0):
                    self.state = 107
                    self.loop_stat()
                    self.state = 112
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 113
                self.match(loopsParser.RCURLY)
                pass
            elif token in [loopsParser.WHILE]:
                self.enterOuterAlt(localctx, 2)
                self.state = 115
                self.match(loopsParser.WHILE)
                self.state = 116
                self.match(loopsParser.LBRACKET)
                self.state = 117
                self.expr(0)
                self.state = 118
                self.match(loopsParser.RBRACKET)
                self.state = 119
                self.match(loopsParser.LCURLY)
                self.state = 123
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.BREAK) | (1 << loopsParser.CONTINUE) | (1 << loopsParser.ID))) != 0):
                    self.state = 120
                    self.loop_stat()
                    self.state = 125
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 126
                self.match(loopsParser.RCURLY)
                pass
            elif token in [loopsParser.IF]:
                self.enterOuterAlt(localctx, 3)
                self.state = 128
                self.match(loopsParser.IF)
                self.state = 129
                self.match(loopsParser.LBRACKET)
                self.state = 130
                self.expr(0)
                self.state = 131
                self.match(loopsParser.RBRACKET)
                self.state = 132
                self.match(loopsParser.LCURLY)
                self.state = 136
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.BREAK) | (1 << loopsParser.CONTINUE) | (1 << loopsParser.ID))) != 0):
                    self.state = 133
                    self.loop_stat()
                    self.state = 138
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 139
                self.match(loopsParser.RCURLY)
                self.state = 155
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==loopsParser.ELIF:
                    self.state = 140
                    self.match(loopsParser.ELIF)
                    self.state = 141
                    self.match(loopsParser.LBRACKET)
                    self.state = 142
                    self.expr(0)
                    self.state = 143
                    self.match(loopsParser.RBRACKET)
                    self.state = 144
                    self.match(loopsParser.LCURLY)
                    self.state = 148
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.BREAK) | (1 << loopsParser.CONTINUE) | (1 << loopsParser.ID))) != 0):
                        self.state = 145
                        self.loop_stat()
                        self.state = 150
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)

                    self.state = 151
                    self.match(loopsParser.RCURLY)
                    self.state = 157
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 165
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.ELSE:
                    self.state = 158
                    self.match(loopsParser.ELSE)
                    self.state = 162
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)
                    while (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.MUL) | (1 << loopsParser.ADD) | (1 << loopsParser.SUB) | (1 << loopsParser.NOT) | (1 << loopsParser.INCR) | (1 << loopsParser.DECR) | (1 << loopsParser.LBRACKET) | (1 << loopsParser.REF) | (1 << loopsParser.CONST) | (1 << loopsParser.SIGNED) | (1 << loopsParser.UNSIGNED) | (1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.INT) | (1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF) | (1 << loopsParser.FLOAT) | (1 << loopsParser.CHAR_PREF) | (1 << loopsParser.CHAR) | (1 << loopsParser.STRING) | (1 << loopsParser.BREAK) | (1 << loopsParser.CONTINUE) | (1 << loopsParser.ID))) != 0):
                        self.state = 159
                        self.loop_stat()
                        self.state = 164
                        self._errHandler.sync(self)
                        _la = self._input.LA(1)



                pass
            elif token in [loopsParser.SWITCH]:
                self.enterOuterAlt(localctx, 4)
                self.state = 167
                self.match(loopsParser.SWITCH)
                self.state = 168
                self.match(loopsParser.LBRACKET)
                self.state = 169
                self.expr(0)
                self.state = 170
                self.match(loopsParser.RBRACKET)
                self.state = 171
                self.match(loopsParser.LCURLY)
                self.state = 177
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,15,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 172
                        self.match(loopsParser.CASE)
                        self.state = 173
                        self.match(loopsParser.D_POINT)
                        self.state = 174
                        self.stat() 
                    self.state = 179
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,15,self._ctx)

                self.state = 183
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.DEFAULT:
                    self.state = 180
                    self.match(loopsParser.DEFAULT)
                    self.state = 181
                    self.match(loopsParser.D_POINT)
                    self.state = 182
                    self.stat()


                self.state = 190
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                while _la==loopsParser.CASE:
                    self.state = 185
                    self.match(loopsParser.CASE)
                    self.state = 186
                    self.match(loopsParser.D_POINT)
                    self.state = 187
                    self.stat()
                    self.state = 192
                    self._errHandler.sync(self)
                    _la = self._input.LA(1)

                self.state = 193
                self.match(loopsParser.RCURLY)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Type_specifierContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.Type_specifierContext, self).__init__(parent, invokingState)
            self.parser = parser

        def SHORT_PREF(self):
            return self.getToken(loopsParser.SHORT_PREF, 0)

        def INT_PREF(self):
            return self.getToken(loopsParser.INT_PREF, 0)

        def LONG_PREF(self):
            return self.getToken(loopsParser.LONG_PREF, 0)

        def LONG_LONG_PREF(self):
            return self.getToken(loopsParser.LONG_LONG_PREF, 0)

        def CHAR_PREF(self):
            return self.getToken(loopsParser.CHAR_PREF, 0)

        def CONST(self):
            return self.getToken(loopsParser.CONST, 0)

        def MUL(self):
            return self.getToken(loopsParser.MUL, 0)

        def SIGNED(self):
            return self.getToken(loopsParser.SIGNED, 0)

        def UNSIGNED(self):
            return self.getToken(loopsParser.UNSIGNED, 0)

        def FLOAT_PREF(self):
            return self.getToken(loopsParser.FLOAT_PREF, 0)

        def DOUBLE_PREF(self):
            return self.getToken(loopsParser.DOUBLE_PREF, 0)

        def LONG_DOUBLE_PREF(self):
            return self.getToken(loopsParser.LONG_DOUBLE_PREF, 0)

        def getRuleIndex(self):
            return loopsParser.RULE_type_specifier

        def enterRule(self, listener):
            if hasattr(listener, "enterType_specifier"):
                listener.enterType_specifier(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitType_specifier"):
                listener.exitType_specifier(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitType_specifier"):
                return visitor.visitType_specifier(self)
            else:
                return visitor.visitChildren(self)




    def type_specifier(self):

        localctx = loopsParser.Type_specifierContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_type_specifier)
        self._la = 0 # Token type
        try:
            self.state = 214
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 198
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.CONST:
                    self.state = 197
                    self.match(loopsParser.CONST)


                self.state = 201
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.SIGNED or _la==loopsParser.UNSIGNED:
                    self.state = 200
                    _la = self._input.LA(1)
                    if not(_la==loopsParser.SIGNED or _la==loopsParser.UNSIGNED):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()


                self.state = 203
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.INT_PREF) | (1 << loopsParser.SHORT_PREF) | (1 << loopsParser.LONG_PREF) | (1 << loopsParser.LONG_LONG_PREF) | (1 << loopsParser.CHAR_PREF))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 205
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.MUL:
                    self.state = 204
                    self.match(loopsParser.MUL)


                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 208
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.CONST:
                    self.state = 207
                    self.match(loopsParser.CONST)


                self.state = 210
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << loopsParser.FLOAT_PREF) | (1 << loopsParser.DOUBLE_PREF) | (1 << loopsParser.LONG_DOUBLE_PREF))) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 212
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==loopsParser.MUL:
                    self.state = 211
                    self.match(loopsParser.MUL)


                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class LiteralContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.LiteralContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return loopsParser.RULE_literal

     
        def copyFrom(self, ctx):
            super(loopsParser.LiteralContext, self).copyFrom(ctx)



    class IntegerContext(LiteralContext):

        def __init__(self, parser, ctx): # actually a loopsParser.LiteralContext)
            super(loopsParser.IntegerContext, self).__init__(parser)
            self.copyFrom(ctx)

        def INT(self):
            return self.getToken(loopsParser.INT, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterInteger"):
                listener.enterInteger(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitInteger"):
                listener.exitInteger(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitInteger"):
                return visitor.visitInteger(self)
            else:
                return visitor.visitChildren(self)


    class FloatContext(LiteralContext):

        def __init__(self, parser, ctx): # actually a loopsParser.LiteralContext)
            super(loopsParser.FloatContext, self).__init__(parser)
            self.copyFrom(ctx)

        def FLOAT(self):
            return self.getToken(loopsParser.FLOAT, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterFloat"):
                listener.enterFloat(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitFloat"):
                listener.exitFloat(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitFloat"):
                return visitor.visitFloat(self)
            else:
                return visitor.visitChildren(self)


    class CharacterContext(LiteralContext):

        def __init__(self, parser, ctx): # actually a loopsParser.LiteralContext)
            super(loopsParser.CharacterContext, self).__init__(parser)
            self.copyFrom(ctx)

        def CHAR(self):
            return self.getToken(loopsParser.CHAR, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterCharacter"):
                listener.enterCharacter(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitCharacter"):
                listener.exitCharacter(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitCharacter"):
                return visitor.visitCharacter(self)
            else:
                return visitor.visitChildren(self)


    class StringContext(LiteralContext):

        def __init__(self, parser, ctx): # actually a loopsParser.LiteralContext)
            super(loopsParser.StringContext, self).__init__(parser)
            self.copyFrom(ctx)

        def STRING(self):
            return self.getToken(loopsParser.STRING, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterString"):
                listener.enterString(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitString"):
                listener.exitString(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitString"):
                return visitor.visitString(self)
            else:
                return visitor.visitChildren(self)



    def literal(self):

        localctx = loopsParser.LiteralContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_literal)
        try:
            self.state = 220
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [loopsParser.FLOAT]:
                localctx = loopsParser.FloatContext(self, localctx)
                self.enterOuterAlt(localctx, 1)
                self.state = 216
                self.match(loopsParser.FLOAT)
                pass
            elif token in [loopsParser.INT]:
                localctx = loopsParser.IntegerContext(self, localctx)
                self.enterOuterAlt(localctx, 2)
                self.state = 217
                self.match(loopsParser.INT)
                pass
            elif token in [loopsParser.STRING]:
                localctx = loopsParser.StringContext(self, localctx)
                self.enterOuterAlt(localctx, 3)
                self.state = 218
                self.match(loopsParser.STRING)
                pass
            elif token in [loopsParser.CHAR]:
                localctx = loopsParser.CharacterContext(self, localctx)
                self.enterOuterAlt(localctx, 4)
                self.state = 219
                self.match(loopsParser.CHAR)
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DeclarationContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.DeclarationContext, self).__init__(parent, invokingState)
            self.parser = parser

        def type_specifier(self):
            return self.getTypedRuleContext(loopsParser.Type_specifierContext,0)


        def ID(self):
            return self.getToken(loopsParser.ID, 0)

        def getRuleIndex(self):
            return loopsParser.RULE_declaration

        def enterRule(self, listener):
            if hasattr(listener, "enterDeclaration"):
                listener.enterDeclaration(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDeclaration"):
                listener.exitDeclaration(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitDeclaration"):
                return visitor.visitDeclaration(self)
            else:
                return visitor.visitChildren(self)




    def declaration(self):

        localctx = loopsParser.DeclarationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_declaration)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 222
            self.type_specifier()
            self.state = 223
            self.match(loopsParser.ID)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class DefinitionContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.DefinitionContext, self).__init__(parent, invokingState)
            self.parser = parser

        def declaration(self):
            return self.getTypedRuleContext(loopsParser.DeclarationContext,0)


        def EQ(self):
            return self.getToken(loopsParser.EQ, 0)

        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)


        def getRuleIndex(self):
            return loopsParser.RULE_definition

        def enterRule(self, listener):
            if hasattr(listener, "enterDefinition"):
                listener.enterDefinition(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitDefinition"):
                listener.exitDefinition(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitDefinition"):
                return visitor.visitDefinition(self)
            else:
                return visitor.visitChildren(self)




    def definition(self):

        localctx = loopsParser.DefinitionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_definition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 225
            self.declaration()
            self.state = 226
            self.match(loopsParser.EQ)
            self.state = 227
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignmentContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.AssignmentContext, self).__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(loopsParser.ID, 0)

        def EQ(self):
            return self.getToken(loopsParser.EQ, 0)

        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)


        def getRuleIndex(self):
            return loopsParser.RULE_assignment

        def enterRule(self, listener):
            if hasattr(listener, "enterAssignment"):
                listener.enterAssignment(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitAssignment"):
                listener.exitAssignment(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitAssignment"):
                return visitor.visitAssignment(self)
            else:
                return visitor.visitChildren(self)




    def assignment(self):

        localctx = loopsParser.AssignmentContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_assignment)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 229
            self.match(loopsParser.ID)
            self.state = 230
            self.match(loopsParser.EQ)
            self.state = 231
            self.expr(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Function_callContext(ParserRuleContext):

        def __init__(self, parser, parent=None, invokingState=-1):
            super(loopsParser.Function_callContext, self).__init__(parent, invokingState)
            self.parser = parser


        def getRuleIndex(self):
            return loopsParser.RULE_function_call

     
        def copyFrom(self, ctx):
            super(loopsParser.Function_callContext, self).copyFrom(ctx)



    class PrintFContext(Function_callContext):

        def __init__(self, parser, ctx): # actually a loopsParser.Function_callContext)
            super(loopsParser.PrintFContext, self).__init__(parser)
            self.copyFrom(ctx)

        def PRINTF(self):
            return self.getToken(loopsParser.PRINTF, 0)
        def LBRACKET(self):
            return self.getToken(loopsParser.LBRACKET, 0)
        def expr(self):
            return self.getTypedRuleContext(loopsParser.ExprContext,0)

        def RBRACKET(self):
            return self.getToken(loopsParser.RBRACKET, 0)

        def enterRule(self, listener):
            if hasattr(listener, "enterPrintF"):
                listener.enterPrintF(self)

        def exitRule(self, listener):
            if hasattr(listener, "exitPrintF"):
                listener.exitPrintF(self)

        def accept(self, visitor):
            if hasattr(visitor, "visitPrintF"):
                return visitor.visitPrintF(self)
            else:
                return visitor.visitChildren(self)



    def function_call(self):

        localctx = loopsParser.Function_callContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_function_call)
        try:
            localctx = loopsParser.PrintFContext(self, localctx)
            self.enterOuterAlt(localctx, 1)
            self.state = 233
            self.match(loopsParser.PRINTF)
            self.state = 234
            self.match(loopsParser.LBRACKET)
            self.state = 235
            self.expr(0)
            self.state = 236
            self.match(loopsParser.RBRACKET)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx, ruleIndex, predIndex):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[2] = self.expr_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def expr_sempred(self, localctx, predIndex):
            if predIndex == 0:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 3)
         




